package testfile;

public class TestFile {

	public static void main(String[] args) {
		System.out.println("Hello World!");

	}

}
