
public class Lab_04 {

	public static void main(String[] args) {
		

	}

}
